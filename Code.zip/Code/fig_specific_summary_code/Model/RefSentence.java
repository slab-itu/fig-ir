package Model;

/**
 * Place holder for a reference sentence (a sentence that mentions one or 
 * more document elements)
 * 
 * @author aum
 *
 */
public class RefSentence {
	public String sentence = null;
	public DocumentNode section;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
